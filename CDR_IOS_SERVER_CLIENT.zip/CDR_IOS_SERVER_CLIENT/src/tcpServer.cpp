#include <myHeader.h>
#include <vector>
#include <cstring>
#include <string>
#include <sstream>
#include <map>
#include <thread>
#include <cstdlib>
#include <pthread.h>
#define NUM_THREADS 5
class Operator
{
        private:
                long operators;
                string name;
                long incom_call;
                long out_call;
                long download;
                long upload;
                long in_msg;
                long out_msg;

        public:
                Operator(){}
                Operator(long o,string b,long c1,long c2,long dow,long up,long in,long out){
                        operators=o;
                        name=b;
                        incom_call=c1;
                        out_call=c2;
                        download=dow;
                        upload=up;
                        in_msg=in;
                        out_msg=out;
                }
                string getName(){
                return name;
                }
                void setIn_c(long c){
                incom_call=c;
                }
                void setOu_c(long c){
                        out_call=c;
                }
                void setdown(long d){
                download=d;
                }
                void setup(long u){
                upload=u;
                }
                void setIn(long i){
                in_msg=i;
                }
                void setOut(long o){
                out_msg=o;
                }
                long getIn_c(){
                return incom_call;
                }
                long getOu_c(){
                return out_call;
                }
                long getdown(){
                return download;
                }
                long getup(){
                return upload;
                }
                long getIn(){
                return in_msg;
                }
                long getout(){
                return out_msg;
                }
                long getId(){
                return operators;
                }
};
long tmp=0;
Operator emp(tmp,"",tmp,tmp,tmp,tmp,tmp,tmp);
const int T_S = 200;
class HashTableEntry {
   public:
      long k;
      Operator v;
      HashTableEntry(long k, Operator v) {
         this->k= k;
         this->v = v;
      }
};
class HashMapTable {
   private:
      HashTableEntry **t;
   public:
      HashMapTable() {
         t = new HashTableEntry * [T_S];
         for (long i = 0; i< T_S; i++) {
            t[i] = NULL;
         }
      }
          HashTableEntry** getTable(){
                return t;
          }
      long HashFunc(long k) {
         return k % T_S;
      }
      void Insert(long k, Operator v) {
         long h = HashFunc(k);
         while (t[h] != NULL && t[h]->k != k) {
            h = HashFunc(h + 1);
         }
         if (t[h] != NULL)
            delete t[h];
         t[h] = new HashTableEntry(k, v);
      }
      Operator SearchKey(long k) {
         long h = HashFunc(k);
         while (t[h] != NULL && t[h]->k != k) {
            h = HashFunc(h + 1);
         }
         if (t[h] == NULL)
            return emp;
         else
            return t[h]->v;
      }
      ~HashMapTable() {
         for (long i = 0; i < T_S; i++) {
            if (t[i] != NULL)
               delete t[i];
            delete[] t;
         }
      }
};
long j=0;
string t,ta[10];
HashMapTable hash1;
static pthread_mutex_t mutex;
void *process_chunk(void *tq){
        pthread_mutex_lock(&mutex);
        string *lt=static_cast<string*>(tq);
        string l=*lt;
        stringstream X(l);
        while(getline(X,t,'|')){
                ta[j++]=t;
        }
        j=0;
        long l1=stol(ta[2]);
        long l2=stol(ta[4]);
        long l3=stol(ta[5]);
        long l4=stol(ta[6]);
        long l5=0;
        long l6=0;
        long t1=0;
        long t2=1;
        //cout << out[l1].getId() ;
        Operator r=hash1.SearchKey(l1);
        if(r.getId()!=0){
        if(ta[3]=="MTC")
                r.setIn_c(r.getIn_c()+l2);
        else if(ta[3]=="MOC")
                 r.setOu_c(r.getOu_c()+l2);
        else if(ta[3]=="GPRS"){
                 r.setdown(r.getdown()+l3);
                  r.setup(r.getup()+l4);
                  }
        else if(ta[3]=="SMS-MT")
                 r.setIn(r.getIn()+1);
        else
                 r.setOut(r.getout()+1);
        hash1.Insert(l1,r);
        }
        else{
                //Operator o;
                if(ta[3]=="MTC"){
                        Operator o(l1,ta[1],t1,l2,l3,l4,l5,l6);
                        hash1.Insert(l1,o);
                        }
                else if(ta[3]=="MOC"){
                        Operator o(l1,ta[1],t1,l2,l3,l4,l5,l6);
                        hash1.Insert(l1,o);
                        }
                else if(ta[3]=="GPRS"){
                        Operator o(l1,ta[1],t1,t1,l3,l4,l5,l6);
                        hash1.Insert(l1,o);
                        }
                else if(ta[3]=="SMS-MT"){
                        Operator o(l1,ta[1],t1,t1,t1,t1,t2,t1);
                        hash1.Insert(l1,o);
                        }
                else{
                        Operator o(l1,ta[1],t1,t1,t1,t1,t1,t2);
                        hash1.Insert(l1,o);
                        }
                //out[l1]=o;
        }
        pthread_mutex_unlock(&mutex);
        pthread_exit(NULL);
}
void process_lines(string lines[]){
      pthread_t threads[NUM_THREADS];

      for (long int i = 0 ; i < NUM_THREADS ; ++i)
      {
          int t = pthread_create(&threads[i], NULL, process_chunk, (void*    )&lines[i]);

          if (t != 0)
          {
              cout << "Error in thread creation: " << t << endl;
          }
      }

       for(int i = 0 ; i < NUM_THREADS; ++i)
      {
          void* status;
          int t = pthread_join(threads[i], &status);
          if (t != 0)
          {
              cout << "Error in thread join: " << t << endl;
              }
      }
}

int main()
{

        int sockfd, ret ;

        struct sockaddr_in sAddr, newAddr;

        socklen_t addr_size, newSockfd;

        char buff[1024];
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if(sockfd < 0)
        {
                perror("socket() error");
                exit(1);
        }

        cout<<"[+]Server socket is created.\n";

        memset(&sAddr,'\0',sizeof(sAddr));

        sAddr.sin_family = AF_INET;
        sAddr.sin_port = htons(4056);
        sAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

        ret = bind(sockfd,(struct sockaddr*)&sAddr,sizeof(sAddr));

        if(ret < 0)
        {
                perror("bind() error");
                exit(1);
        }

        cout<<"[+]Bind to the port: "<<4055<<endl;


        if(listen(sockfd,10) == 0)
                cout<<"[+]Listening....."<<endl;
        else
                cout<<"[-]Error in binding"<<endl;
        while(1){
                memset(&buff,'\0',sizeof(buff));
                newSockfd = accept(sockfd,(struct sockaddr*) &newAddr, &addr_size);
                if(newSockfd < 0)
                {
                        perror("accept() error");
                        exit(1);
                }
                if(fork() == 0){

                        while(1){
                                //recv(newSockfd, buff, 1024,0);
                                read(newSockfd, buff, 1024);
                                if(strcmp(buff,":Bye") == 0 || strcmp(buff,"")==0)
                                {
                                        bzero(buff, sizeof(buff));
                                        cout<<"Disconnected Client"<<endl;
                                        break;
                                }
                                else
                                {
                                    cout<<"size"<<sizeof(buff)<<endl;
                                        cout<<"Client Message: "<<buff<<endl;
                                        ifstream file(buff);
                                        string l;
                                        if(!file)
                                        {
                                        cout<<"Unable to open"<<endl;
                                        }
                                        else
                                        {
                                                cout <<"Proccessing Data"<<endl;
                                                string lines[5];
                                                int i=0;
                                                while(getline(file,l)){
                                        lines[i++]=l;
                                        if(i>=5){
                                        process_lines(lines);
                                i=0;
                                }
                                }

                                }
                                ofstream outfile;
                                outfile.open("out.txt");
                                HashTableEntry **tmp1=hash1.getTable();
                                for(int i=0;i<T_S;i++){
                                if(tmp1[i]!=NULL)
                        outfile<< "Operator Brand: " <<  (tmp1[i]->v).getName() << " ("<<  (tmp1[i]->v).getId()<< ")\n\tIncoming voice call durations: "<<   (tmp1[i]->v).getIn_c() <<"\n\tOutgoing voice call durations: "<<   (tmp1[i]->v).getOu_c()<<"\n\tIncoming SMS messages: "<<   (tmp1[i]->v).getIn()<<"\n\tOutgoing SMS messages: "<<   (tmp1[i]->v).getout()<<"\n\tMB downloaded: "<<   (tmp1[i]->v).getdown()<<" | MB uploaded: "<<   (tmp1[i]->v).getup()<<endl;
                                }
                                outfile.close();
                                char buff1[]="Processed the cdr file and created out.txt file";
                                write(newSockfd, buff1, strlen(buff1));
                                bzero(buff, sizeof(buff));
                                bzero(buff1, sizeof(buff1));
                                }
                        }
                }
                else
                {
                        close(sockfd);
                        //close(newSockfd);
                        wait(0);
                }

        }

        close(newSockfd);

        return 0;
}